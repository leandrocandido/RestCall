﻿namespace RestCall
{
    public class CountryDataResponse
    {
        public string name { get; set; }
        public int population { get; set; }
    }
}
